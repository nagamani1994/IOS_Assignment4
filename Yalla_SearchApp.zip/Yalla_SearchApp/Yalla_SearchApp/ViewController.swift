//
//  ViewController.swift
//  Yalla_SearchApp
//
//  Created by student on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
        
        @IBOutlet weak var searchOption: UIButton!
        
        @IBOutlet weak var resultImage: UIImageView!
        
        @IBOutlet weak var prevImage: UIButton!
        @IBOutlet weak var nextImage: UIButton!
        
        @IBOutlet weak var topicinfoText: UITextView!
        
     
        @IBOutlet weak var resetAction: UIButton!
        
        var imageNumber = 0;
        var topic: Int = -1
        var count1 : Int = -1
        var arr = [
                   ["Simg1","Simg2","Simg3","Simg4","Simg5"],
                   ["Cimg1","Cimg2","Cimg3","Cimg4","Cimg5"],
                   ["Pimg1","Pimg2","Pimg3","Pimg4","Pimg5"]]
        
        var Superhero_keywords = ["Superhero","Batman","Aquaman","Ironman","Krish" , "Blackwidow" , "super"]
        var Car_keywords = ["car","BMW","Audi","Bentley","Ferrari","LandRover","SuperCar"]
        var places_keywords = ["Indore","Delhi","Place","Mysore","Maryville"]
        var topics_array = [["Aquaman's most widely recognized power, apart from being able to breathe underwater, is the ability to communicate with marine life, which he can summon from great distances. This was originally described in the stories as an ability to actually speak with fish,into an ability to communicate with them telepathically.","Batman ventures into Gotham City's underworld when a sadistic killer leaves behind a trail of cryptic clues. As the evidence begins to lead closer to home and the scale of the perpetrator's plans become clear, he must forge new relationships, unmask the culprit and bring justice to the abuse of power and corruption that has long plagued the metropolis.","Natasha Romanoff, aka Black Widow, confronts the darker parts of her ledger when a dangerous conspiracy with ties to her past arises. Pursued by a force that will stop at nothing to bring her down, Natasha must deal with her history as a spy, and the broken relationships left in her wake long before she became an Avenger."," A billionaire industrialist and genius inventor, Tony Stark (Robert Downey Jr.), is conducting weapons tests overseas, but terrorists kidnap him to force him to build a devastating weapon. Instead, he builds an armored suit and upends his captors. "," Five-year-old Krishna Mehra is the son of scientist, Rohit and his late wife Nisha. He lives in the town of Kasauli. He undergoes an intelligence quotient (IQ) test by his catholic school principal who suspects that Krishna has superpowers like his father, due to Krishna answering all the questions flawlessly. His grandmother, Sonia, takes the young Krishna to a remote mountain village to conceal his unique abilities."],
            ["Audi AG is a German automotive manufacturer of luxury vehicles headquartered in Ingolstadt, Bavaria, Germany. As a subsidiary of its parent company, the Volkswagen Group, Audi produces vehicles in nine production facilities worldwide"," Bentley Motors Limited is a British manufacturer and marketer of luxury cars and SUVs, and a subsidiary of the Volkswagen Group since 1998. Headquartered in Crewe, England, the company was founded as Bentley Motors Limited by W. O."," Bayerische Motoren Werke AG, commonly referred to as BMW, is a German multinational corporate manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria, Germany."," Ferrari S.p.A. is an Italian luxury sports car manufacturer based in Maranello, Italy. Founded by Enzo Ferrari in 1939 from the Alfa Romeo racing division as Auto Avio Costruzioni, the company built its first car in 1940, and produced its first Ferrari-badged car in 1947. "," Land Rover is a British brand of predominantly four-wheel drive, off-road capable vehicles, owned by multinational car manufacturer Jaguar Land Rover, since 2008 a subsidiary of India's Tata Motors. JLR currently builds Land Rovers in Brazil, China, India, Slovakia, and the United Kingdom."],
            ["Chennai, on the Bay of Bengal in eastern India, is the capital of the state of Tamil Nadu. The city is home to Fort St. George, built in 1644 and now a museum showcasing the city’s roots as a British military garrison and East India Company trading outpost, when it was called Madras.."," Delhi, India’s capital territory, is a massive metropolitan area in the country’s north. In Old Delhi, a neighborhood dating to the 1600s, stands the imposing Mughal-era Red Fort, a symbol of India, and the sprawling Jama Masjid mosque, whose courtyard accommodates 25,000 people."," Indore is a city in west-central India. It’s known for the 7-story Rajwada Palace and the Lal Baag Palace, which date back to Indore’s 19th-century Holkar dynasty. The Holkar rulers are honored by a cluster of tombs and cenotaphs at Chhatri Baag. The night market Sarafa Bazar sells street food. "," Mysore (or Mysuru), a city in India's southwestern Karnataka state, was the capital of the Kingdom of Mysore from 1399 to 1947. In its center is opulent Mysore Palace, seat of the former ruling Wodeyar dynasty. "," The City of Maryville does not discriminate based on race, color or national origin in federal or state approved."]]
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            searchOption.isEnabled = false
            nextImage.isHidden = true
            prevImage.isHidden = true
            resetAction.isHidden = true
            resultImage.image = UIImage(named: "default")

            //On Loading the app we need to display default Image
        }


        @IBAction func searchFieldAction(_ sender: Any) {
            searchOption.isEnabled = true
        }
        
        @IBAction func searchButtonAction(_ sender: UIButton) {
            if(Superhero_keywords.contains(searchTextField.text!)){
                topic = 0
                imageNumber = 0
                buttonsDisable()
            }
            else if(Car_keywords.contains(searchTextField.text!)){
                topic = 1
                imageNumber = 0
                buttonsDisable()
            }
            else if(places_keywords.contains(searchTextField.text!)){
                topic = 2
                imageNumber = 0;
                buttonsDisable()
            }
            else{
                topic = -1
                resultImage.image = UIImage(named: "default")
                topicinfoText.text = "No matches with the given Key words. Please try again."
                resetAction.isHidden = true
                nextImage.isHidden = true
                prevImage.isHidden = true
            }
            
            if(topic != -1)
            {
                prevImage.isEnabled = false
                nextImage.isEnabled = true
                count1 = arr[topic].count
                resultImage.image = UIImage(named: arr[topic][0])
                topicinfoText.text = topics_array[topic][0]
            }
            
        }
        
        @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
                nextImage.isEnabled = true;
                imageNumber -= 1
                resultImage.image = UIImage(named: arr[topic][imageNumber])
                topicinfoText.text = topics_array[topic][imageNumber]
                if(imageNumber == 0){
                            prevImage.isEnabled = false
                    }
        
        }
        
        @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
                prevImage.isEnabled = true
                imageNumber += 1
                resultImage.image = UIImage(named: arr[topic][imageNumber])
                topicinfoText.text = topics_array[topic][imageNumber]
                if(imageNumber == count1-1){
                    nextImage.isEnabled = false
                }
        }
        
        @IBAction func resetButton(_ sender: Any) {
            nextImage.isHidden = true
            prevImage.isHidden = true
            resetAction.isHidden = true
            searchTextField.text = ""
            searchOption.isEnabled = false
            topicinfoText.text = ""
            resultImage.image = UIImage(named: "default")
            
        }
        func buttonsDisable(){
            nextImage.isHidden = false
            prevImage.isHidden = false
            resetAction.isHidden = false
        }
        


    }


